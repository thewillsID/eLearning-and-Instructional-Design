function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5adBrlpMSul":
        Script1();
        break;
      case "5ehcKcWJUPu":
        Script2();
        break;
      case "5cNZKMJrv4E":
        Script3();
        break;
      case "5mH98hoY72k":
        Script4();
        break;
      case "6FjmFSZqvXG":
        Script5();
        break;
      case "5nfZeO8hBPE":
        Script6();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
window.Script1 = function()
{
  player.once(() => {
const target = object('5sDjEbCGv3y');
const duration = 750;
const easing = 'ease-out';
const id = '5s0W9xi41JI';
const pulseAmount = 0.07;
const delay = 13188;
addToTimeline(
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script2 = function()
{
  player.once(() => {
const target = object('5sDjEbCGv3y');
const duration = 750;
const easing = 'ease-out';
const id = '5s0W9xi41JI';
const pulseAmount = 0.07;
const delay = 15750;
addToTimeline(
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script3 = function()
{
  player.once(() => {
const target = object('5sDjEbCGv3y');
const duration = 750;
const easing = 'ease-out';
const id = '5s0W9xi41JI';
const pulseAmount = 0.07;
const delay = 17625;
addToTimeline(
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script4 = function()
{
  player.once(() => {
const target = object('6Bb6vL4SBTG');
const duration = 750;
const easing = 'ease-out';
const id = '6XkJLh3yLRe';
const pulseAmount = 0.07;
const delay = 2000;
addToTimeline(
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script5 = function()
{
  player.once(() => {
const target = object('6kftkKYmj9T');
const duration = 750;
const easing = 'ease-out';
const id = '6XkJLh3yLRe';
const pulseAmount = 0.07;
const delay = 2000;
addToTimeline(
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script6 = function()
{
  player.once(() => {
const target = object('5rz2wrkFkxL');
const duration = 750;
const easing = 'ease-out';
const id = '6XkJLh3yLRe';
const pulseAmount = 0.07;
const delay = 2000;
addToTimeline(
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

};
